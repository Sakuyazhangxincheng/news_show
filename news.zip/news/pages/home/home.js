// pages/home/home.js
Page({
  data: {
  
    tabCur: 0, //默认选中
    tabs: [{
        name: '推荐',
        id: 0
      },
      {
        name: '头条',
        id: 1
      },
      {
        name: '娱乐',
        id: 2
      },
      {
        name: '体育',
        id: 3
      },
      {
        name: '游戏',
        id: 4
      },
      {
        name: '科技',
        id: 5
      },
      {
        name: '国际',
        id: 6
      },
      {
        name: '财经',
        id: 8
      }
    ]

  },

  //选择条目
  tabSelect(e) {
    this.setData({
      tabCur: e.currentTarget.dataset.id,
      scrollLeft: (e.currentTarget.dataset.id - 2) * 200
    })
  }
})